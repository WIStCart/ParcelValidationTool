This sample dataset has been modified to include errors that will be identified by the Validation and Submission Tool. Any questions about this example data should be directed to Codie See (csee@wisc.edu) or David Vogel (djvogel2@wisc.edu) of the State Cartographer's Office.  Please note that this is example data and is not representative of the actual data pertaining to these parcels contained within.   

NOTE: County to select in tool interface is VERNON.

